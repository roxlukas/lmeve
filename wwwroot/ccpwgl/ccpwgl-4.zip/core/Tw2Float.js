﻿function Tw2Float() {
    this.value = 0;
}