/**
 * Tw2Float
 * @property {number} value
 * @constructor
 */
function Tw2Float() 
{
    this.value = 0;
}
