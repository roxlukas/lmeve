function EveLocator()
{
    this.name = '';
    this.transform = mat4.create();
}

